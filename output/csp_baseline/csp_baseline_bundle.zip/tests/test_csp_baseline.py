"""Brute-force oracle and original-environment integration checks."""
import itertools
import unittest

import numpy as np

from lib.csp_agent import CSPAgent


def make_board(agent, mines):
    truth = np.zeros(agent.rows * agent.cols, dtype=np.int32)
    for i, neighbors in enumerate(agent.neighbors):
        truth[i] = -2 if i in mines else len(set(neighbors) & mines)
    return truth.reshape(agent.rows, agent.cols)


def oracle(agent, visible):
    flat = visible.reshape(-1)
    unknown = list(map(int, np.flatnonzero(flat == -1)))
    valid = []
    for cells in itertools.combinations(unknown, agent.num_mines):
        mines = set(cells)
        if all(len(set(agent.neighbors[i]) & mines) == flat[i]
               for i in np.flatnonzero(flat >= 0)):
            valid.append(mines)
    if not valid:
        return None
    return {i: sum(i in mines for mines in valid) / len(valid) for i in unknown}


class CSPTests(unittest.TestCase):
    def test_probabilities_against_exhaustive_oracle(self):
        rng = np.random.RandomState(931)
        enumerations = 0
        nontrivial_safe = 0
        for _ in range(500):
            agent = CSPAgent(3, 4, 3, max_iterations=100000)
            mines = set(map(int, rng.choice(12, 3, replace=False)))
            truth = make_board(agent, mines)
            visible = np.full((3, 4), -1, dtype=np.int32)
            safe = sorted(set(range(12)) - mines)
            revealed = rng.choice(safe, rng.randint(1, len(safe)), replace=False)
            visible.reshape(-1)[revealed] = truth.reshape(-1)[revealed]
            expected = oracle(agent, visible)
            self.assertIsNotNone(expected)
            decision = agent.decide(visible)
            self.assertIn(decision.action, expected)
            self.assertTrue(decision.exact)
            for i, p in expected.items():
                if np.isfinite(decision.probabilities[i]):
                    self.assertAlmostEqual(decision.probabilities[i], p, places=10)
            if decision.reason == "enumerated":
                enumerations += 1
                self.assertAlmostEqual(expected[decision.action], min(expected.values()), places=10)
                if expected[decision.action] == 0:
                    nontrivial_safe += 1
        self.assertGreater(enumerations, 10)
        self.assertGreater(nontrivial_safe, 0)  # proves inference beyond single-point rules

    def test_budget_and_timeout_discard_partial_counts(self):
        visible = np.full((9, 9), -1, dtype=np.int32)
        visible[0, 0] = 1
        limited = CSPAgent(num_mines=10, max_iterations=1).decide(visible)
        self.assertEqual(limited.reason, "iteration_limit")
        self.assertFalse(limited.exact)
        timed = CSPAgent(num_mines=10, timeout_seconds=1e-15).decide(visible)
        self.assertEqual(timed.reason, "timeout")
        self.assertEqual(visible.reshape(-1)[timed.action], -1)

    def test_upstream_propagation_regression(self):
        agent = CSPAgent(3, 4, 3)
        visible = np.array([[-1, -1, -1, -1], [-1, -1, 3, 2], [1, -1, -1, 1]])
        decision = agent.decide(visible)
        expected = oracle(agent, visible)
        self.assertEqual(decision.reason, "enumerated")
        for i, p in expected.items():
            self.assertAlmostEqual(decision.probabilities[i], p, places=12)
        self.assertEqual(decision.probabilities[4], 0)

    def test_globally_unsatisfiable_enumeration(self):
        visible = np.array([[-1, 1, -1], [1, -1, 1], [-1, 1, -1]])
        agent = CSPAgent(3, 3, 3)
        self.assertIsNone(oracle(agent, visible))
        decision = agent.decide(visible)
        self.assertEqual(decision.reason, "no_solution")
        self.assertGreater(decision.iterations, 0)
        self.assertFalse(decision.exact)

    def test_inconsistent_clues_and_no_unknown(self):
        agent = CSPAgent(2, 2, 1)
        decision = agent.decide(np.array([[3, -1], [0, -1]]))
        self.assertEqual(decision.reason, "no_solution")
        self.assertFalse(decision.exact)
        self.assertIn(decision.action, (1, 3))
        self.assertIsNone(agent.decide(np.zeros((2, 2), dtype=int)).action)
        with self.assertRaises(ValueError):
            agent.decide(np.array([[-2, -1], [-1, -1]]))

    def test_interface_is_observation_only_and_deterministic(self):
        visible = np.full((9, 9), -1, dtype=np.int32)
        self.assertEqual(CSPAgent().decide(visible).action, 0)
        visible[0, 0] = 1
        before = visible.copy()
        a, b = CSPAgent().decide(visible), CSPAgent().decide(visible)
        self.assertEqual(a.action, b.action)
        np.testing.assert_array_equal(a.probabilities, b.probabilities)
        np.testing.assert_array_equal(visible, before)
        self.assertFalse(hasattr(CSPAgent(), "env"))

    def test_proven_safe_priority_and_first_click_probability(self):
        self.assertEqual(CSPAgent._choose(np.array([1e-15, 0.0]), [0, 1]), 1)
        decision = CSPAgent().decide(np.full((9, 9), -1))
        self.assertEqual(decision.probabilities[0], 0.0)
        self.assertAlmostEqual(decision.probabilities.sum(), 10.0)

    def test_original_first_click_and_terminal_states(self):
        from minesweeper_pygame import MinesweeperEnv
        env = MinesweeperEnv(9, 9, 10, "rgb_array")
        for seed in range(30):
            np.random.seed(seed)
            env.reset()
            state, _, done, info = env.step(0)
            self.assertNotEqual(state[0, 0], -2)
            self.assertNotEqual(info["status"], "lose")
        # Ground truth access in TEST FIXTURES only: force a loss and finish a win.
        np.random.seed(42)
        env.reset()
        env.step(0)
        mine = int(np.flatnonzero(env.board.reshape(-1) == -2)[0])
        _, _, done, info = env.step(mine)
        self.assertTrue(done)
        self.assertEqual(info["status"], "lose")
        self.assertEqual(env.stats["n_lose"], 1)
        env.reset()
        env.step(0)
        while not env.done:
            safe = np.flatnonzero((env.player_board.reshape(-1) == -1)
                                  & (env.board.reshape(-1) != -2))
            _, _, done, info = env.step(int(safe[0]))
        self.assertEqual(info["status"], "win")
        self.assertEqual(env.stats["n_win"], 1)
        env.close()

    def test_episode_seed_reproducibility_and_audit_isolation(self):
        from baseline_evaluation import play_episode
        from minesweeper_pygame import MinesweeperEnv
        class OtherPolicy:
            # Changes actions but has the same observed first click.
            stats = {}
            def decide(self, visible):
                from lib.csp_agent import Decision
                unknown = np.flatnonzero(visible.reshape(-1) == -1)
                return Decision(int(unknown[-1]), np.zeros(visible.size), "test", False)
        for seed in range(10):
            env = MinesweeperEnv(9, 9, 18, "rgb_array")
            a = play_episode(env, CSPAgent(num_mines=18), seed, seed, 18)
            b = play_episode(env, CSPAgent(num_mines=18), seed, seed, 18)
            for key in a:
                if key != "seconds":
                    self.assertEqual(a[key], b[key])
            c = play_episode(env, OtherPolicy(), seed, seed, 18)
            self.assertEqual(a["initial_board_sha256"], c["initial_board_sha256"])
            self.assertEqual(a["first_click_board_sha256"], c["first_click_board_sha256"])
            self.assertEqual(a["error"], "")
            env.close()


if __name__ == "__main__":
    unittest.main()
